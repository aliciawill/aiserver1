function outCall() {
    alert('외부에서 참조한 outCall함수입니다.')
}